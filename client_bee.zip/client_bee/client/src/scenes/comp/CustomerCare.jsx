import custm from './custm.jpg';
import './customercare.css';
function CustomerCare ()  {
  return (
    <div className="h2">
      <img src={custm}/>
    </div>
  )
}

export default CustomerCare
