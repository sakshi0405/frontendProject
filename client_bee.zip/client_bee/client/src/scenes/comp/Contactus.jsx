// // import React from 'react'

// // function Contactus () {
// //   return (
// //     <div>
      
// //     </div>
// //   )
// // }

// // export default Contactus

// import React, { useState } from 'react';

// function Contactus() {
//   const [formData, setFormData] = useState({
//     name: '',
//     email: '',
//     message: ''
//   });

//   const handleSubmit = (event) => {
//     event.preventDefault();
//     console.log(formData);
//     // Send form data to a server or an email address
//   }

//   const handleInputChange = (event) => {
//     const { name, value } = event.target;
//     setFormData({ ...formData, [name]: value });
//   }

//   return (
//     <div>
     
//       <h1>Contact Us</h1>
//       <form onSubmit={handleSubmit}>
//         <label htmlFor="name">Name</label>
//         <input type="text" name="name" value={formData.name} onChange={handleInputChange} /><br></br>
        
//         <label htmlFor="email">Email</label>
//         <input type="email" name="email" value={formData.email} onChange={handleInputChange} /><br></br>
//         <label htmlFor="message">Message</label>
//         <textarea name="message" value={formData.message} onChange={handleInputChange} /><br></br>
//         <button type="submit">Submit</button>
//       </form>
//     </div>
//   );
// }

// export default Contactus;
import React from 'react'
import './contact.css';
const Contactus = () => {
  const [formStatus, setFormStatus] = React.useState('Send')
  const onSubmit = (e) => {
    e.preventDefault()
    setFormStatus('Submitting...')
    const { name, email, message } = e.target.elements
    let conFom = {
      name: name.value,
      email: email.value,
      message: message.value,
    }
    console.log(conFom)
  }
  return (
    <div className="h1">
    <div className="container mt-5">
      <h2 className="mb-3"> Contact us Form </h2>
      <form onSubmit={onSubmit}>
        <div className="mb-3">
          <label className="form-label" htmlFor="name">
            Name
          </label>
          <input className="form-control" type="text" id="name" required />
        </div>
        <div className="mb-3">
          <label className="form-label" htmlFor="email">
            Email
          </label>
          <input className="form-control" type="email" id="email" required />
        </div>
        <div className="mb-3">
          <label className="form-label" htmlFor="message">
            Message
          </label>
          <textarea className="form-control" id="message" required />
        </div>
        <button className="btn btn-danger" type="submit">
          {formStatus}
        </button>
      </form>
    </div>
  </div>
  )
}
export default Contactus