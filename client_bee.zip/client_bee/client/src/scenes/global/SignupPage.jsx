// import { Margin } from "@mui/icons-material";
import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import './SignupPage.css';

function SignupPage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [warning, setWarning] = useState(false);
  const [emailError, setEmailError] = useState("");
  const [passwordError, setPasswordError] = useState(false);
  const [confirmPasswordError, setConfirmPasswordError] = useState(false);


  const handleChange = (event) => {
    const { value } = event.target;
    
    if (/^[a-zA-Z\s]*$/.test(value)) {
      setName(value);
      setWarning(false);
    }
    else{
        setWarning(true);
    }
    // setEmail(value);
    // validateEmail(value);
  };

function handleChange1(event){
    const {value}=event.target;
    // setEmail((prev)=>{
    //     return{
    //         ...prev,
    //         email:[value]
    //     }
    // })
    setEmail(value);
    validateEmail(value);
    console.log("h");
};






  const validateEmail = (email) => {
    console.log("e");
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!regex.test(email)) {
      setEmailError("Please enter a valid email address");
    } else {
      setEmailError("");
    }
  };
  const handlePasswordChange = (e) => {
    setPassword(e.target.value);
    if (e.target.value.length < 8) {
      setPasswordError(true);
    } else {
      setPasswordError(false);
    }
  };
  const handleConfirmPasswordChange = (e) => {
    const confirmPasswordValue = e.target.value;
    setConfirmPassword(confirmPasswordValue);
    if (password !== confirmPasswordValue) {
      setConfirmPasswordError(true);
    } else {
      setConfirmPasswordError(false);
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (password.length >= 8) {
        // handle signup logic here
      } else {
        setPasswordError(true);
      }
    // Perform sign up authentication with name, email, and password
    // Redirect user to home page on successful sign up
  };

  return (
    
    <div className="abc">
        <div className="s1">
      <h1>Sign Up</h1>
      <form onSubmit={handleSubmit}>
        <div>
            <br></br>
          <label>Name:</label>
          <input
            type="text"
            value={name}
            onChange={handleChange}
            required
          />
          {warning && <p style={{ color: "red" }}>Please enter only alphabets</p>}
        </div>
        <div>
        <br></br>
          <label>Email:</label>
          <input
            type="email"
            value={email}
            onChange={handleChange1} 
            required
          />
           <br></br>
          {emailError && <p style={{ color: "red" }}>{emailError}</p>}
        </div>
        <div>
          <label>Password:</label>
          <input
            type="password"
            value={password}
            onChange={handlePasswordChange}
            required
          />
           <br></br>
           {passwordError && <div style={{ color: 'red' }}>Password must be at least 8 characters long</div>}
        </div>
        <div>
        <br></br>
          <label>Confirm Password:</label>
          <input
            type="password"
            value={confirmPassword}
            onChange={handleConfirmPasswordChange}
            required
          />
            {confirmPasswordError && <p className="signup-error">Passwords do not match</p>}
        </div>
        <br></br>
       <NavLink exact to="/login"><button type="submit">Sign Up</button></NavLink> 
      </form>
    </div>
    </div>
  );
}

export default SignupPage;