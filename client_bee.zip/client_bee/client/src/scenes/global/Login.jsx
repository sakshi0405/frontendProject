import React, { useState } from 'react';
import { NavLink, Navigate } from "react-router-dom";
import './Login.css';
// import { WidthNormal } from '@mui/icons-material';


const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleUsernameChange = (event) => {
    setUsername(event.target.value);
  };

  const handlePasswordChange = (event) => {
    setPassword(event.target.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    // Perform validation
    if (username === 'u' && password === 'p') {
      setIsLoggedIn(true);
    } else {
      setError('Incorrect username or password');
    }
  };

  if (isLoggedIn) {
    return <Navigate to="/Home" />;
  }

  return (
    
    <form  className='j' onSubmit={handleSubmit} >
  <div className='s'>
      <div className='u'>
      <h1>Login Here</h1>
        <label htmlFor="username">Username:</label>
        <input type="text" id="username" value={username} onChange={handleUsernameChange} required />
      </div>
      <div>
        <label htmlFor="password">Password:</label>
        <input type="password" id="password" value={password} onChange={handlePasswordChange} required />
      </div>
      <button type="submit" className='btn' >Login</button>
      <NavLink exact to="/SignupPage"><p>Don't have an account? SignUp Here</p><button className="btn1" type="submit">SignupPage</button></NavLink>
      {error && <div>{error}</div>}
      </div>
    </form>
  );
};

export default Login;